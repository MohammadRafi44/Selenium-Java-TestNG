# SeleniumFramework_ExcelFlag

SeleniumFramework_ExcelFlag is a test automation framework that built in Java programming language. Using Selenium test automation tools.

Concepts Included:
Data Driven.

Keyword Driven.

Page Object pattern and Page Factory. POM

Common web page interaction methods.

Objects shared repository.

Tools
Java
Selenium WebDriver. seleniumhq.org

Installation
Install Java 11
Install selenium libraries

Download Selenium Drivers.
Selenium requires a driver to interface with the chosen browser.

Chrome: [https://sites.google.com/a/chromium.org/chromedriver/downloads]

Edge: [https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/]

Firefox: [https://github.com/mozilla/geckodriver/releases]

Safari: [https://webkit.org/blog/6900/webdriver-support-in-safari-10/]

Getting Started.
Clone the SeleniumFramework_ExcelFlag project. [https://github.com/pavankunapareddy5/SeleniumFramework_ExcelFlag.git]

Open the project in Eclipse. Select the work space file.


Please for more details do not hesitate to contact me at LinkedIn

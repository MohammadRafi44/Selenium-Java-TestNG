package com.training.reports;

public class AllureReporting {


}
